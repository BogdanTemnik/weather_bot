import telebot
import pyowm
import time
import datetime
from telebot import types

bot = telebot.TeleBot('1281503623:AAGIWTXTvXu9i45GBhdya8eKtBabPWOoCDE')
owm = pyowm.OWM('0d7f07cac663ee5add7fb06630032b25')

stop = False


def show_me_time_list(message):
    with open('data/timelist.txt') as file:
        data = file.read()

    if data == '':
        bot.send_message(message.chat.id, 'error, time list is empty.')
    else:
        with open('data/timelist.txt') as file:
            time_list_set_list = list(set(file.read().split()))

        to_output_list = []
        for i in range(len(time_list_set_list)):
            to_output_list.append(time_list_set_list[i])
            to_output_list.append(', ')

        del to_output_list[-1]

        start_show_me_list = telebot.types.InlineKeyboardMarkup()
        start_show_me_list.add(telebot.types.InlineKeyboardButton('start', callback_data='start_show_me_list'))
        bot.send_message(message.chat.id, 'list: ' + ''.join(to_output_list), reply_markup=start_show_me_list)

def start_output_weather_at_time(message):
    check = True
    '''
    with open('commands/start.txt') as file:
        data = file.read()

    bot.send_message(message.chat.id, data)
    '''
    print(stop)
    # time algorithm
    minuteStart = datetime.datetime.now().strftime('%M')

    while True:

        with open('data/timelist.txt') as file:
            data = file.read()

        t2 = datetime.datetime.now()
        res = t2.strftime('%M')  # всегда меняем текущую минуту

        if res in data and check == True and res > minuteStart:  # Дополнительно проверяем текущая минута не больше чем стартовая, если больше то один раз выводим на экран погоду)
            output_weather(message)
            minuteStart = res  # Снова меняем стартовую минуту на текущую запуская минутный интервал спячки
            break
        check = True


def output_weather(message):
    with open('data/city.txt') as file:
        place = file.read()
    try:
        observation = owm.weather_at_place(place)
        w = observation.get_weather()
        temperature = w.get_temperature('celsius')
        status = w.get_detailed_status()
        bot.send_message(message.chat.id, 'at ' + place + ':\n\tstatus: ' + status + '\n\ttotal temperature: ' + str(
            temperature['temp']) + '\n\tmax: ' + str(temperature['temp_max']) + '\n\tmin: ' + str(temperature['temp_min']))
        if temperature['temp'] < 15:
            bot.send_message(message.chat.id, 'put on warm clothes😊')
        elif temperature['temp'] >= 15 and temperature['temp'] <= 25:
            bot.send_message(message.chat.id, 'you need to put on cap😝')
        elif temperature['temp'] >= 30:
            bot.send_message(message.chat.id, 'you can put off t-shirt🥵')
        elif temperature['temp'] < 0:
            bot.send_message(message.chat.id, 'today is cold. Put on jacket and hat🥵')
    except:
        if place == '':
            bot.send_message(message.chat.id, 'error, input city/country at "set city"')
        else:
            bot.send_message(message.chat.id, 'error, unknown city/country')


def loc(message):
    global location
    location = message.text
    file = open('data/city.txt', 'w')
    file.write(location)
    bot.send_message(message.chat.id, 'your location is ' + location)


def first_num_from_replace(message):
    global first_num
    first_num = message.text
    with open('data/timelist.txt') as file:
        time_list_in_list = list(set(file.read().split()))

    if first_num not in time_list_in_list:
        bot.send_message(message.chat.id, 'error, time not found.')
    else:
        with open('data/buf_first_num.txt', 'w') as file:
            file.write(first_num)
        print('first number saved to bufer.')

        bot.send_message(message.chat.id, 'for what to replace: ')
        bot.register_next_step_handler(message, second_num_from_replace)


def second_num_from_replace(message):
    second_num = message.text

    with open('data/timelist.txt') as file:
        data = file.read()

    if data == '':
        bot.send_message(message.chat.id, 'error, time list is empty.')
    else:
        with open('data/timelist.txt') as file:
            time_list_set_list = list(set(file.read().split()))
        
        print(time_list_set_list)

        #replace
        index = 0
        for i in range(len(time_list_set_list)):
            if time_list_set_list[i] == first_num:
                time_list_set_list[i] = second_num
                break

        #create unique time list with replaced times
        time_list_set_list = list(set(time_list_set_list))

        #create list of time list with replaced times
        time_list_to_save = []
        for i in range(len(time_list_set_list)):
            time_list_to_save.append(time_list_set_list[i])
            time_list_to_save.append('\n')

        print('list to save:', time_list_to_save)

        #SAVE to time list file data/timelist.txt
        string_to_file = ''.join(time_list_to_save)

        with open('data/timelist.txt', 'w') as file:
            file.write(string_to_file)

        #output to telegram
        with open('data/timelist.txt') as file:
            time_list_to_telegram = list(set(file.read().split()))

        print('time list to telegram:', time_list_to_telegram)

        #create list with commas and edit him
        time_list_comma = []
        for i in range(len(time_list_to_telegram)):
            time_list_comma.append(time_list_to_telegram[i])
            time_list_comma.append(', ')

        print('time list with comma with comma at end: ', time_list_comma)

        del time_list_comma[-1]

        print('time list with comma: ', time_list_comma)

        string_to_telegram = ''.join(time_list_comma)

        #output
        start_replace_time = telebot.types.InlineKeyboardMarkup()
        start_replace_time.add(telebot.types.InlineKeyboardButton('start', callback_data='start_replace_time'))
        bot.send_message(message.chat.id, 'time replaced.')
        bot.send_message(message.chat.id, 'list: ' + string_to_telegram, reply_markup=start_replace_time)





def append_time(message):
    hour = message.text

    with open('data/timelist.txt') as file:
        time_list_set_list = list(set(file.read().split()))

    #append to time list user's new time
    time_list_set_list.append(hour)

    print('with append:', time_list_set_list)

    #create set in list, string who save to file timelist.txt
    to_save_list = []
    for i in range(len(time_list_set_list)):
        to_save_list.append(time_list_set_list[i] + '\n')

    to_save_str = ''.join(list(set(to_save_list)))
    print('set: ', to_save_str)

    #save time list to file timelst.txt
    with open('data/timelist.txt', 'w') as file:
        file.write(to_save_str)

    #output ot telegram
    with open('data/timelist.txt') as file:
        data = file.read().split()

    time_list_with_comma_and_space = []
    for i in range(len(data)):
        time_list_with_comma_and_space.append(data[i])
        time_list_with_comma_and_space.append(', ')

    #del last element
    del time_list_with_comma_and_space[-1]

    print(time_list_with_comma_and_space)

    to_telegram_string = ''.join(time_list_with_comma_and_space)

    #output to telegram and add button "start" - to start output weather automatically
    start_append_time = telebot.types.InlineKeyboardMarkup()
    start_append_time.add(telebot.types.InlineKeyboardButton('start', callback_data='start_append_time'))
    bot.send_message(message.chat.id, 'list: ' + to_telegram_string)
    bot.send_message(message.chat.id, 'time appended.', reply_markup=start_append_time)


def delete_one_of_list(message):
    hour = message.text

    with open('data/timelist.txt') as file:
        data = file.read().split()

    #validation: if hour in time list
    if hour not in data:
        bot.send_message(message.chat.id, 'error, time not found.')
    else:
        with open('data/timelist.txt') as file:
            time_list_set_list = list(set(file.read().split()))

        print(time_list_set_list)

        #delete time
        index = 0

        for i in range(len(time_list_set_list)):
            if time_list_set_list[i] == hour:
                index = i
                break

        print('delete time:', time_list_set_list[index])

        del time_list_set_list[index]

        print('time list after delete:', time_list_set_list)

        if len(time_list_set_list) == 0:
            print('empty time list.')

            with open('data/timelist.txt', 'w') as file:
                file.write('')

            bot.send_message(message.chat.id, 'you delete last time. Time list is empty.')
        else:
            #create string and save time list with deleted time to file data/timelist.txt
            to_save_list = []
            time_list_set_list = list(set(time_list_set_list))

            for i in range(len(time_list_set_list)):
                to_save_list.append(time_list_set_list[i])
                to_save_list.append('\n')

            with open('data/timelist.txt', 'w') as file:
                file.write(''.join(to_save_list))

            #output ot telegram
            with open('data/timelist.txt') as file:
                data = file.read()

            if data == '':
                bot.send_message(message.chat.id, 'error, time list is empty.')
            else:
                with open('data/timelist.txt') as file:
                    time_list_set_list = list(set(file.read().split()))

                #create list of time list for output ot telegram
                to_telegram_list = []

                for i in range(len(time_list_set_list)):
                    to_telegram_list.append(time_list_set_list[i])
                    to_telegram_list.append(', ')

                print('telegram list with comma at end:', to_telegram_list)

                del to_telegram_list[-1]

                print('telegram list:', to_telegram_list)

                #output
                start_delete_time = telebot.types.InlineKeyboardMarkup()
                start_delete_time.add(telebot.types.InlineKeyboardButton('start', callback_data='start_delete_message'))
                bot.send_message(message.chat.id, 'time deleted.')
                bot.send_message(message.chat.id, 'list: ' + ''.join(to_telegram_list), reply_markup=start_delete_time)


#bot commands
@bot.message_handler(commands=['start', 'help'])
def get_command(message):

    if message.text == '/start':
        commands_keyboard = telebot.types.InlineKeyboardMarkup()
        commands_keyboard.add(telebot.types.InlineKeyboardButton('set city', callback_data='set_city'))
        commands_keyboard.add(telebot.types.InlineKeyboardButton('weather now', callback_data='weather_now'))
        commands_keyboard.add(telebot.types.InlineKeyboardButton('edit time list', callback_data='edit_time_list'))
        bot.send_message(message.chat.id, 'hello, im your weather bot. I will send you weather at your location.', reply_markup=commands_keyboard)


#events handler
@bot.callback_query_handler(func=lambda call:True)
def get_callback(query):
    if query.data.startswith('set_city'):
        with open('commands/setcity.txt') as file:
            data = file.read()
        bot.send_message(query.message.chat.id, data)
        bot.register_next_step_handler(query.message, loc)
        # bot.send_message(message.chat.id, 'INPUT CITY/COUNTRY WITH FIRST LETTER IN UPPER CASE.')

    elif query.data.startswith('weather_now'):
        output_weather(query.message)

    elif query.data.startswith('edit_time_list'):
        edit_commands = telebot.types.InlineKeyboardMarkup()
        edit_commands.add(telebot.types.InlineKeyboardButton('append time', callback_data='append_time'))
        edit_commands.add(telebot.types.InlineKeyboardButton('clear (delete all times)', callback_data='clear'))
        edit_commands.add(telebot.types.InlineKeyboardButton('replace (one of list)', callback_data='replace'))
        edit_commands.add(telebot.types.InlineKeyboardButton('delete (one of list)', callback_data='delete'))
        edit_commands.add(telebot.types.InlineKeyboardButton('show time list', callback_data='show_time_list'))
        bot.send_message(query.message.chat.id, 'choose: ', reply_markup=edit_commands)

    if query.data.startswith('clear'):
        with open('data/timelist.txt', 'w') as file:
            file.write('')
        bot.send_message(query.message.chat.id, 'time list is clear.')

    elif query.data.startswith('replace'):
        with open('data/timelist.txt') as file:
            data = file.read()
        if data == '':
            bot.send_message(query.message.chat.id, 'time list is empty.')
        else:
            #output for telegram
            with open('data/timelist.txt') as file:
                time_list_in_str = file.read().replace('\n', ', ')

            time_list_in_list = []
            for i in range(len(time_list_in_str)):
                time_list_in_list.append(time_list_in_str[i])

            del time_list_in_list[-1]
            del time_list_in_list[-1]
            time_list_in_str = ''.join(time_list_in_list)

            '''
            request replace data (число которое хотим поменять, на что хотим поменять)
            this two numbers finds two functions: 
            '''

            bot.send_message(query.message.chat.id, 'time list: ' + time_list_in_str)
            bot.send_message(query.message.chat.id, 'input hour who you want to replace: ')
            bot.register_next_step_handler(query.message, first_num_from_replace)

    elif query.data.startswith('show_time_list'):
        show_me_time_list(query.message)

    elif query.data.startswith('append_time'):
        bot.send_message(query.message.chat.id, 'input hour who you want to append: ')
        bot.register_next_step_handler(query.message, append_time)
    elif query.data.startswith('delete'):
        with open('data/timelist.txt') as file:
            data = file.read()
        if data != '':
            bot.send_message(query.message.chat.id, 'input hour who you want to delete: ')
            bot.register_next_step_handler(query.message, delete_one_of_list)
        else:
            bot.send_message(query.message.chat.id, 'error, time list is empty.')

    #add all events for start button
    elif query.data.startswith('start_append_time'):
        start_output_weather_at_time(query.message)
    elif query.data.startswith('start_replace_time'):
        start_output_weather_at_time(query.message)
    elif query.data.startswith('start_delete_time'):
        start_output_weather_at_time(query.message)
    elif query.data.startswith('start_show_me_list'):
        start_output_weather_at_time(query.message)


    #unknown commands handler
@bot.message_handler(content_types=['text'])
def get_unknown_command(message):
    bot.send_message(message.chat.id, 'unknown command.')

bot.polling()