import datetime
import time

stop = False

def tm(hour):
    res = []
    i = 0
    while i < 24:
        res.append(i)
        i += hour
    return res

def to_string_list(l):
    for i in range(len(l)):
        l[i] = str(l[i])

check = True
'''
a = int(input('input n hours: '))
hours_list = tm(a)
to_string_list(hours_list)
#print(hours_list)
'''

lak = []

for i in range(60):
    lak.append(str(i))

#print(lak)
    
#Записываем минуту старта
minuteStart = datetime.datetime.now().strftime('%M')


while stop != True:
    t2 = datetime.datetime.now()
    res = t2.strftime('%M') #всегда меняем текущую минуту
    
    if res in lak and check == True and res > minuteStart: #Дополнительно проверяем текущая минута не больше чем стартовая, если больше то один раз выводим на экран погоду)
        print('weather here')
        check = False
        minuteStart = res #Снова меняем стартовую минуту на текущую запуская минутный интервал спячки
    check = True


#На код, который дальше не обращайте внимание








































'''
a = 5
l = []
t2 = 0
res = 0
while True:
    t2 = datetime.datetime.now()
    res = t2.strftime('%M')
    hgj = [1, '15', 2]
    print(res)
    if res in hgj:
        print('rfgdf')
'''

