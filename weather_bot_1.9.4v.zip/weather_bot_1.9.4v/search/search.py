file = open('GEODATASOURCE-CITIES-FREE.TXT')
data = file.read().split()
file.close()
res = []

file = open('cities.txt', 'a')
for i in range(len(data)):
    if len(data[i]) > 2:
        print(i, ' copy ', data[i])
        file.write(data[i] + '\n')

file.close()
